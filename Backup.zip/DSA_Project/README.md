# Phonebook Application

## General Explanation

This is a simple **Phonebook Application** designed for a telecommunications company. It allows users to perform basic phonebook operations such as inserting, searching, updating, deleting, and displaying contacts. Additionally, the program provides a search efficiency analysis feature, and contacts are stored persistently in a text file (`contacts.txt`), allowing them to be saved and accessed across multiple sessions.

The application is built using **Java** and utilizes simple linear data structures (LinkedList) for contact storage. File handling is implemented to save and load contact data from a text file, making the application suitable for environments where file-based storage is preferred over databases.

---

## Modules and Components

The application is structured in a modular fashion, with each module handling a specific aspect of the phonebook functionality. Below is an overview of the key modules:

### 1. `Contact` Class

This class represents an individual contact, encapsulating details like name, phone number, and email address. It also includes methods for displaying and converting contact information to and from text for file handling.

### 2. `PhonebookOperations` Interface

This interface defines the core operations that any phonebook implementation should support, such as adding, searching, updating, and deleting contacts.

### 3. `Phonebook` Class

The main class that implements `PhonebookOperations`. It stores contacts in a LinkedList and handles the file operations. Contacts are loaded from a file (`contacts.txt`) upon initialization and saved after every change.

### 4. `PhonebookApp` Class (Main Class)

This class provides the user interface (command-line interface) where users can interact with the phonebook by selecting options from a menu.

---

## Function Descriptions

### 1. `Contact` Class

- `Contact(String name, String phone, String email)`: Constructor to create a new contact with the provided name, phone, and email.
- `getName()`: Returns the contact's name.
- `getPhone()`: Returns the contact's phone number.
- `setPhone(String phone)`: Sets a new phone number for the contact.
- `getEmail()`: Returns the contact's email.
- `setEmail(String email)`: Sets a new email address for the contact.
- `display()`: Displays the contact's information in the console.
- `toString()`: Converts the contact's information into a comma-separated string for file storage.
- `static fromString(String line)`: Parses a string and returns a `Contact` object, used for loading contacts from the file.

### 2. `PhonebookOperations` Interface

Defines the core operations for phonebook management:

- `insertContact(String name, String phone, String email)`: Adds a new contact to the phonebook.
- `searchContact(String name)`: Searches for a contact by name and returns the contact if found.
- `displayAllContacts()`: Displays all the contacts in the phonebook.
- `deleteContact(String name)`: Deletes a contact by name from the phonebook.
- `updateContact(String name, String newPhone, String newEmail)`: Updates the phone number and email for an existing contact.
- `sortContacts()`: Sorts the contacts alphabetically by name.
- `analyzeSearchEfficiency(String name)`: Analyzes how many comparisons it took to find a contact during a search.

### 3. `Phonebook` Class

- `Phonebook()`: Constructor that initializes the LinkedList of contacts and loads the contacts from the file.
- `loadContactsFromFile()`: Loads all contacts from the `contacts.txt` file into the LinkedList.
- `saveContactsToFile()`: Saves all contacts from the LinkedList to the `contacts.txt` file.
- `insertContact(String name, String phone, String email)`: Adds a contact to the LinkedList and saves it to the file.
- `searchContact(String name)`: Searches for a contact by name in the LinkedList.
- `displayAllContacts()`: Displays all contacts in the LinkedList.
- `deleteContact(String name)`: Deletes a contact by name and saves the change to the file.
- `updateContact(String name, String newPhone, String newEmail)`: Updates the contact information and saves the change to the file.
- `sortContacts()`: Sorts contacts by name and saves the sorted contacts to the file.
- `analyzeSearchEfficiency(String name)`: Counts and displays the number of comparisons made during the search.

### 4. `PhonebookApp` Class

- Contains the `main()` method, which is the entry point of the program.
- Implements a menu-driven interface for the user to choose actions like inserting, updating, deleting, and searching for contacts.

---

## File Storage

The phonebook data is stored in a text file named `contacts.txt`. Each line in the file represents a single contact, with details (name, phone number, and email) separated by commas. The application will load this file when it starts, and write back any changes (insertions, deletions, updates) to the file.

---

## Contributor Names

- **We All**: Lead Developer
- **We All**: Software Architect
- **We All**: Testing and Documentation
- **We All**: File Handling and Persistence

---

## How to Run the Application

1. Compile all `.java` files:
   ```bash
   javac *.java
