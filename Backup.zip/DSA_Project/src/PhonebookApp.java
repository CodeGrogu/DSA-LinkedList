import java.util.Scanner;

public class PhonebookApp {
    public static void main(String[] args) {
        Phonebook phonebook = new Phonebook();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nPhonebook Menu:");
            System.out.println("1. Insert Contact");
            System.out.println("2. Search Contact");
            System.out.println("3. Display All Contacts");
            System.out.println("4. Delete Contact");
            System.out.println("5. Update Contact");
            System.out.println("6. Sort Contacts");
            System.out.println("7. Analyze Search Efficiency");
            System.out.println("8. Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Phone: ");
                    String phone = scanner.nextLine();
                    System.out.print("Enter Email: ");
                    String email = scanner.nextLine();
                    phonebook.insertContact(name, phone, email);
                    break;
                case 2:
                    System.out.print("Enter Name to Search: ");
                    name = scanner.nextLine();
                    Contact contact = phonebook.searchContact(name);
                    if (contact != null) {
                        contact.display();
                    } else {
                        System.out.println("Contact not found.");
                    }
                    break;
                case 3:
                    phonebook.displayAllContacts();
                    break;
                case 4:
                    System.out.print("Enter Name to Delete: ");
                    name = scanner.nextLine();
                    phonebook.deleteContact(name);
                    break;
                case 5:
                    System.out.print("Enter Name to Update: ");
                    name = scanner.nextLine();
                    System.out.print("Enter New Phone: ");
                    phone = scanner.nextLine();
                    System.out.print("Enter New Email: ");
                    email = scanner.nextLine();
                    phonebook.updateContact(name, phone, email);
                    break;
                case 6:
                    phonebook.sortContacts();
                    phonebook.displayAllContacts();
                    break;
                case 7:
                    System.out.print("Enter Name to Analyze Search: ");
                    name = scanner.nextLine();
                    phonebook.analyzeSearchEfficiency(name);
                    break;
                case 8:
                    System.out.println("Exiting Phonebook.");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
