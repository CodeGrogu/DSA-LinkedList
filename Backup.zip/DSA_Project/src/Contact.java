public class Contact {
    private String name;
    private String phone;
    private String email;

    public Contact(String name, String phone, String email) {
        this.name = name;
        this.phone = phone;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Display contact information
    public void display() {
        System.out.println("Name: " + name + ", Phone: " + phone + ", Email: " + email);
    }

    // Parse a string to create a Contact object
    public static Contact fromString(String contactString) {
        String[] parts = contactString.split(",");
        if (parts.length != 3) {
            throw new IllegalArgumentException("Invalid contact string format. Expected format: 'name,phone,email'");
        }
        String name = parts[0].trim();
        String phone = parts[1].trim();
        String email = parts[2].trim();
        return new Contact(name, phone, email);
    }

    @Override
    public String toString() {
        return name + "," + phone + "," + email;
    }
}
