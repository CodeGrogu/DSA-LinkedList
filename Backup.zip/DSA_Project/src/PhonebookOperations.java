interface PhonebookOperations {
    void insertContact(String name, String phone, String email);
    Contact searchContact(String name);
    void displayAllContacts();
    void deleteContact(String name);
    void updateContact(String name, String newPhone, String newEmail);
    void sortContacts();
    void analyzeSearchEfficiency(String name);
}
