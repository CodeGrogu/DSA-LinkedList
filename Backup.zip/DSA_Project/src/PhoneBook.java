import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Collections;
//import java.util.Comparator;

public class Phonebook implements PhonebookOperations {
    private LinkedList<Contact> contacts;
    private static final String filename = "contacts.txt";

    public Phonebook() {
        contacts = new LinkedList<>();
        loadContactsFromFile();  // Load contacts when Phonebook is initialized
    }

    // Load contacts from the file into the LinkedList
    private void loadContactsFromFile() {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                Contact contact = Contact.fromString(line);
                if (contact != null) {
                    contacts.add(contact);
                }
            }
        } catch (IOException e) {
            System.out.println("No existing contacts found, starting fresh.");
        }
    }

    // Save contacts to the file
    private void saveContactsToFile() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename))) {
            for (Contact contact : contacts) {
                bw.write(contact.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving contacts to file.");
        }
    }

    // Insert a new contact and save to file
    public void insertContact(String name, String phone, String email) {
        contacts.add(new Contact(name, phone, email));
        saveContactsToFile();
        System.out.println("Contact added successfully.");
    }

    // Search Contact with partial match using recursive binary search
    @Override
    public Contact searchContact(String name) {
        // Ensure the contacts are sorted before performing binary search
        sortContacts();
        return binarySearch(contacts, name.toLowerCase(), 0, contacts.size() - 1);
    }

    private Contact binarySearch(LinkedList<Contact> contacts, String name, int low, int high) {
        if (low > high) {
            return null;
        }

        int mid = (low + high) / 2;
        Contact midContact = contacts.get(mid);
        String midName = midContact.getName().toLowerCase();

        if (midName.contains(name)) {
            return midContact;
        } else if (midName.compareTo(name) < 0) {
            return binarySearch(contacts, name, mid + 1, high);
        } else {
            return binarySearch(contacts, name, low, mid - 1);
        }
    }

    // Display All Contacts
    @Override
    public void displayAllContacts() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts found.");
            return;
        }
        for (Contact contact : contacts) {
            contact.display();
        }
    }

    // Delete Contact
    @Override
    public void deleteContact(String name) {
        Contact contact = searchContact(name);
        if (contact != null) {
            contacts.remove(contact);
            System.out.println("Contact deleted successfully.");
            saveContactsToFile();  // Save to file after deletion
        } else {
            System.out.println("Contact not found.");
        }
    }

    // Update Contact
    @Override
    public void updateContact(String name, String newPhone, String newEmail) {
        Contact contact = searchContact(name);
        if (contact != null) {
            contact.setPhone(newPhone);
            contact.setEmail(newEmail);
            System.out.println("Contact updated successfully.");
            saveContactsToFile();  // Save to file after update
        } else {
            System.out.println("Contact not found.");
        }
    }

    // Sort Contacts by Name using QuickSort
    @Override
    public void sortContacts() {
        quickSort(contacts, 0, contacts.size() - 1);
        //System.out.println("Contacts sorted successfully.");
        saveContactsToFile();  // Save to file after sorting
    }

    private void quickSort(LinkedList<Contact> list, int low, int high) {
        if (low < high) {
            int pi = partition(list, low, high);
            quickSort(list, low, pi - 1);
            quickSort(list, pi + 1, high);
        }
    }

    private int partition(LinkedList<Contact> list, int low, int high) {
        Contact pivot = list.get(high);
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (list.get(j).getName().compareToIgnoreCase(pivot.getName()) <= 0) {
                i++;
                Collections.swap(list, i, j);
            }
        }
        Collections.swap(list, i + 1, high);
        return i + 1;
    }

    // Analyze Search Efficiency
    @Override
    public void analyzeSearchEfficiency(String name) {
        int comparisons = 0;
        for (Contact contact : contacts) {
            comparisons++;
            if (contact.getName().toLowerCase().contains(name.toLowerCase())) {
                System.out.println("Contact found: " + contact.getName() + ", after " + comparisons + " comparisons.");
                return;
            }
        }
        System.out.println("Contact not found. Total comparisons made: " + comparisons);
    }
}
